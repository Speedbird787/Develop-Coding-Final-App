Extract the folder Animal Galaxy and run the .exe file from inside the folder.
-Sha